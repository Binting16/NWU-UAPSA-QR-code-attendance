# QR Attendance Scanner — Android App

Scan student QR codes, log attendance with timestamps, and export to Excel or CSV.  
Works **100% offline** once installed. Optional Google Drive upload when connected.

---

## ⚡ Quickest way to get the APK — GitHub Actions (no local tools needed)

1. **Create a free GitHub account** at github.com if you don't have one.

2. **Create a new repository** — click the `+` button → *New repository*.  
   Name it anything (e.g. `qr-attendance`). Make it **Public** or **Private** — both work.

3. **Upload these project files** into the repo:  
   - Click *uploading an existing file* on the empty repo page.  
   - Select all the files/folders you extracted from this ZIP (including the `android/` folder).  
   - Commit them.

4. **GitHub Actions automatically starts a build.**  
   Go to the **Actions** tab of your repo → click the latest run → wait ~5–10 minutes for the first build.

5. **Download the APK:**  
   At the bottom of the completed Action run, find **Artifacts → QR-Attendance-debug-apk**.  
   Click it to download `app-debug.apk`.

6. **Install on Android:**  
   - Transfer the APK to your Android phone.  
   - Open it — Android will ask to allow installing from unknown sources. Tap *Install*.  
   - Done! Find "QR Attendance" in your app drawer.

> After the first build, every time you push a change GitHub will rebuild automatically.  
> You can also trigger a manual rebuild from the **Actions** tab → *Run workflow*.

---

## 🛠 Build locally with Android Studio (alternative)

If you prefer building on your own machine:

1. Install [Android Studio](https://developer.android.com/studio) (free).
2. Install [Node.js 20+](https://nodejs.org).
3. In a terminal, inside this project folder:
   ```bash
   npm install --legacy-peer-deps
   npx cap sync
   ```
4. Open the `android/` folder in Android Studio.
5. Wait for Gradle to sync, then go to **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
6. The APK will be at `android/app/build/outputs/apk/debug/app-debug.apk`.

---

## 📱 Using the app

### First-time setup
1. **Import your roster** (tap ⬆ Roster in the toolbar):  
   Your Excel/CSV file must have **Column A = Full Name**, **Column B = Student ID**.
2. **Set the session label** — defaults to today's date; change it per event.
3. **Set an export file name** — e.g. "Orientation Day 2026".

### Scanning attendance
1. Tap **Start Scanning** and allow camera permission when asked.
2. Point camera at a student's QR code — the app beeps and highlights their row green.
3. Unknown IDs show a popup to add them on the spot.
4. Duplicate scans are flagged with a different sound.

### Exporting
- Tap **CSV** or **Excel** — Android's share sheet pops up.
- Choose **Save to Files** to save locally, or share directly to Drive/Gmail/WhatsApp.
- **Excel** produces a styled file with green cells for present students, ready to match your master roster.
- **Drive** button uploads directly to Google Drive (requires internet + one-time sign-in setup).

### Multiple sessions / dates
Each time you scan with a different session label (e.g. a new date), a new column is added.  
You can run the app across multiple events and the roster accumulates all attendance columns.

---

## ☁️ Google Drive setup (optional)

The **Drive** button needs a Google OAuth Client ID. Set it in the ⚙️ Settings panel:

1. Go to [Google Cloud Console](https://console.cloud.google.com).
2. Create a project → enable the **Google Drive API**.
3. Go to **APIs & Services → Credentials → Create OAuth Client ID**.
4. Choose **Web application** (yes, web — Capacitor uses HTTPS).
5. Add `https://localhost` as an **Authorized JavaScript origin**.
6. Copy the Client ID and paste it into the app's Settings panel.

---

## 📁 Project structure

```
qr-attendance-android/
├── www/                     ← Web app (bundled into the APK)
│   ├── index.html           ← Full app UI + logic
│   └── js/
│       ├── html5-qrcode.min.js   ← QR scanner (offline)
│       └── xlsx.bundle.js        ← Excel export (offline)
├── android/                 ← Android native project (Capacitor-generated)
├── .github/workflows/
│   └── build-apk.yml        ← GitHub Actions CI build
├── capacitor.config.json
└── package.json
```

---

## 🔧 Customizing the app icon

Replace the icons in `android/app/src/main/res/mipmap-*/` with your own images.  
Use [Android Asset Studio](https://romannurik.github.io/AndroidAssetStudio/) to generate all sizes from one image, then paste them in.

---

## 📝 Notes

- Student data and logs are saved **on-device** in the app's private storage. Uninstalling the app clears this data.
- The app targets **Android 8.0+** (API 26+).
- The debug APK can be sideloaded but shows "App not verified by Google Play". For Play Store distribution, a signed release APK is needed (Android Studio → Generate Signed Bundle).
